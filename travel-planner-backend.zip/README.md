# Travel Planner Backend

FastAPI + PostgreSQL + Docker starter project for authentication microservice.
